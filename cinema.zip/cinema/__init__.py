from .page import render_cinema_page  # mantém API simples no app.py
